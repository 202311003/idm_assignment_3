This zip archive contains data files from Cricsheet in JSON format. This
archive contains 283 ICC Men's Cricket World Cup matches.


The JSON data files contained in this zip file are version 1.0.0, and 1.1.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/icc_mens_cricket_world_cup_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-11-10 - international - ODI - male - 1384433 - Afghanistan vs South Africa
2023-11-09 - international - ODI - male - 1384432 - Sri Lanka vs New Zealand
2023-11-08 - international - ODI - male - 1384431 - England vs Netherlands
2023-11-07 - international - ODI - male - 1384430 - Afghanistan vs Australia
2023-11-06 - international - ODI - male - 1384429 - Sri Lanka vs Bangladesh
2023-11-05 - international - ODI - male - 1384428 - India vs South Africa
2023-11-04 - international - ODI - male - 1384426 - New Zealand vs Pakistan
2023-11-04 - international - ODI - male - 1384427 - Australia vs England
2023-11-03 - international - ODI - male - 1384425 - Netherlands vs Afghanistan
2023-11-02 - international - ODI - male - 1384424 - India vs Sri Lanka
2023-11-01 - international - ODI - male - 1384423 - South Africa vs New Zealand
2023-10-31 - international - ODI - male - 1384422 - Bangladesh vs Pakistan
2023-10-30 - international - ODI - male - 1384421 - Sri Lanka vs Afghanistan
2023-10-29 - international - ODI - male - 1384420 - India vs England
2023-10-28 - international - ODI - male - 1384418 - Australia vs New Zealand
2023-10-28 - international - ODI - male - 1384419 - Netherlands vs Bangladesh
2023-10-27 - international - ODI - male - 1384417 - Pakistan vs South Africa
2023-10-26 - international - ODI - male - 1384416 - England vs Sri Lanka
2023-10-25 - international - ODI - male - 1384415 - Australia vs Netherlands
2023-10-24 - international - ODI - male - 1384414 - South Africa vs Bangladesh
2023-10-23 - international - ODI - male - 1384413 - Pakistan vs Afghanistan
2023-10-22 - international - ODI - male - 1384412 - New Zealand vs India
2023-10-21 - international - ODI - male - 1384410 - Netherlands vs Sri Lanka
2023-10-21 - international - ODI - male - 1384411 - South Africa vs England
2023-10-20 - international - ODI - male - 1384409 - Australia vs Pakistan
2023-10-19 - international - ODI - male - 1384408 - Bangladesh vs India
2023-10-18 - international - ODI - male - 1384407 - New Zealand vs Afghanistan
2023-10-17 - international - ODI - male - 1384406 - Netherlands vs South Africa
2023-10-16 - international - ODI - male - 1384405 - Sri Lanka vs Australia
2023-10-15 - international - ODI - male - 1384404 - Afghanistan vs England
2023-10-14 - international - ODI - male - 1384403 - Pakistan vs India
2023-10-13 - international - ODI - male - 1384402 - Bangladesh vs New Zealand
2023-10-12 - international - ODI - male - 1384401 - South Africa vs Australia
2023-10-11 - international - ODI - male - 1384400 - Afghanistan vs India
2023-10-10 - international - ODI - male - 1384398 - England vs Bangladesh
2023-10-10 - international - ODI - male - 1384399 - Sri Lanka vs Pakistan
2023-10-09 - international - ODI - male - 1384397 - New Zealand vs Netherlands
2023-10-08 - international - ODI - male - 1384396 - Australia vs India
2023-10-07 - international - ODI - male - 1384394 - Afghanistan vs Bangladesh
2023-10-07 - international - ODI - male - 1384395 - South Africa vs Sri Lanka
2023-10-06 - international - ODI - male - 1384393 - Pakistan vs Netherlands
2023-10-05 - international - ODI - male - 1384392 - England vs New Zealand
2019-07-14 - international - ODI - male - 1144530 - England vs New Zealand
2019-07-11 - international - ODI - male - 1144529 - Australia vs England
2019-07-09 - international - ODI - male - 1144528 - India vs New Zealand
2019-07-06 - international - ODI - male - 1144526 - India vs Sri Lanka
2019-07-06 - international - ODI - male - 1144527 - Australia vs South Africa
2019-07-05 - international - ODI - male - 1144525 - Bangladesh vs Pakistan
2019-07-04 - international - ODI - male - 1144524 - Afghanistan vs West Indies
2019-07-03 - international - ODI - male - 1144523 - England vs New Zealand
2019-07-02 - international - ODI - male - 1144522 - Bangladesh vs India
2019-07-01 - international - ODI - male - 1144521 - Sri Lanka vs West Indies
2019-06-30 - international - ODI - male - 1144520 - England vs India
2019-06-29 - international - ODI - male - 1144518 - Afghanistan vs Pakistan
2019-06-29 - international - ODI - male - 1144519 - Australia vs New Zealand
2019-06-28 - international - ODI - male - 1144517 - South Africa vs Sri Lanka
2019-06-27 - international - ODI - male - 1144516 - India vs West Indies
2019-06-26 - international - ODI - male - 1144515 - New Zealand vs Pakistan
2019-06-25 - international - ODI - male - 1144514 - England vs Australia
2019-06-24 - international - ODI - male - 1144513 - Afghanistan vs Bangladesh
2019-06-23 - international - ODI - male - 1144512 - Pakistan vs South Africa
2019-06-22 - international - ODI - male - 1144510 - Afghanistan vs India
2019-06-22 - international - ODI - male - 1144511 - New Zealand vs West Indies
2019-06-21 - international - ODI - male - 1144509 - England vs Sri Lanka
2019-06-20 - international - ODI - male - 1144508 - Australia vs Bangladesh
2019-06-19 - international - ODI - male - 1144507 - New Zealand vs South Africa
2019-06-18 - international - ODI - male - 1144506 - England vs Afghanistan
2019-06-17 - international - ODI - male - 1144505 - Bangladesh vs West Indies
2019-06-16 - international - ODI - male - 1144504 - India vs Pakistan
2019-06-15 - international - ODI - male - 1144502 - Australia vs Sri Lanka
2019-06-15 - international - ODI - male - 1144503 - Afghanistan vs South Africa
2019-06-14 - international - ODI - male - 1144501 - England vs West Indies
2019-06-12 - international - ODI - male - 1144499 - Australia vs Pakistan
2019-06-10 - international - ODI - male - 1144497 - South Africa vs West Indies
2019-06-09 - international - ODI - male - 1144496 - Australia vs India
2019-06-08 - international - ODI - male - 1144494 - England vs Bangladesh
2019-06-08 - international - ODI - male - 1144495 - Afghanistan vs New Zealand
2019-06-06 - international - ODI - male - 1144492 - Australia vs West Indies
2019-06-05 - international - ODI - male - 1144490 - India vs South Africa
2019-06-05 - international - ODI - male - 1144491 - Bangladesh vs New Zealand
2019-06-04 - international - ODI - male - 1144489 - Afghanistan vs Sri Lanka
2019-06-03 - international - ODI - male - 1144488 - England vs Pakistan
2019-06-02 - international - ODI - male - 1144487 - Bangladesh vs South Africa
2019-06-01 - international - ODI - male - 1144485 - New Zealand vs Sri Lanka
2019-06-01 - international - ODI - male - 1144486 - Afghanistan vs Australia
2019-05-31 - international - ODI - male - 1144484 - Pakistan vs West Indies
2019-05-30 - international - ODI - male - 1144483 - England vs South Africa
2015-03-29 - international - ODI - male - 656495 - Australia vs New Zealand
2015-03-26 - international - ODI - male - 656493 - Australia vs India
2015-03-24 - international - ODI - male - 656491 - New Zealand vs South Africa
2015-03-21 - international - ODI - male - 656489 - New Zealand vs West Indies
2015-03-20 - international - ODI - male - 656487 - Australia vs Pakistan
2015-03-19 - international - ODI - male - 656485 - Bangladesh vs India
2015-03-18 - international - ODI - male - 656483 - South Africa vs Sri Lanka
2015-03-15 - international - ODI - male - 656479 - United Arab Emirates vs West Indies
2015-03-15 - international - ODI - male - 656481 - Ireland vs Pakistan
2015-03-14 - international - ODI - male - 656475 - India vs Zimbabwe
2015-03-14 - international - ODI - male - 656477 - Australia vs Scotland
2015-03-13 - international - ODI - male - 656471 - New Zealand vs Bangladesh
2015-03-13 - international - ODI - male - 656473 - Afghanistan vs England
2015-03-12 - international - ODI - male - 656469 - South Africa vs United Arab Emirates
2015-03-11 - international - ODI - male - 656467 - Scotland vs Sri Lanka
2015-03-10 - international - ODI - male - 656465 - India vs Ireland
2015-03-09 - international - ODI - male - 656463 - Bangladesh vs England
2015-03-08 - international - ODI - male - 656459 - New Zealand vs Afghanistan
2015-03-08 - international - ODI - male - 656461 - Australia vs Sri Lanka
2015-03-07 - international - ODI - male - 656455 - Pakistan vs South Africa
2015-03-07 - international - ODI - male - 656457 - Ireland vs Zimbabwe
2015-03-06 - international - ODI - male - 656453 - India vs West Indies
2015-03-05 - international - ODI - male - 656451 - Bangladesh vs Scotland
2015-03-04 - international - ODI - male - 656447 - Pakistan vs United Arab Emirates
2015-03-04 - international - ODI - male - 656449 - Australia vs Afghanistan
2015-03-03 - international - ODI - male - 656445 - Ireland vs South Africa
2015-03-01 - international - ODI - male - 656441 - England vs Sri Lanka
2015-03-01 - international - ODI - male - 656443 - Pakistan vs Zimbabwe
2015-02-28 - international - ODI - male - 656437 - New Zealand vs Australia
2015-02-28 - international - ODI - male - 656439 - India vs United Arab Emirates
2015-02-27 - international - ODI - male - 656435 - South Africa vs West Indies
2015-02-26 - international - ODI - male - 656431 - Afghanistan vs Scotland
2015-02-26 - international - ODI - male - 656433 - Bangladesh vs Sri Lanka
2015-02-25 - international - ODI - male - 656429 - Ireland vs United Arab Emirates
2015-02-24 - international - ODI - male - 656427 - West Indies vs Zimbabwe
2015-02-23 - international - ODI - male - 656425 - England vs Scotland
2015-02-22 - international - ODI - male - 656421 - Afghanistan vs Sri Lanka
2015-02-22 - international - ODI - male - 656423 - India vs South Africa
2015-02-21 - international - ODI - male - 656417 - Pakistan vs West Indies
2015-02-20 - international - ODI - male - 656415 - New Zealand vs England
2015-02-19 - international - ODI - male - 656413 - United Arab Emirates vs Zimbabwe
2015-02-18 - international - ODI - male - 656411 - Afghanistan vs Bangladesh
2015-02-17 - international - ODI - male - 656409 - New Zealand vs Scotland
2015-02-16 - international - ODI - male - 656407 - Ireland vs West Indies
2015-02-15 - international - ODI - male - 656403 - South Africa vs Zimbabwe
2015-02-15 - international - ODI - male - 656405 - India vs Pakistan
2015-02-14 - international - ODI - male - 656399 - New Zealand vs Sri Lanka
2015-02-14 - international - ODI - male - 656401 - Australia vs England
2011-04-02 - international - ODI - male - 433606 - India vs Sri Lanka
2011-03-30 - international - ODI - male - 433605 - India vs Pakistan
2011-03-29 - international - ODI - male - 433604 - Sri Lanka vs New Zealand
2011-03-26 - international - ODI - male - 433603 - Sri Lanka vs England
2011-03-25 - international - ODI - male - 433602 - New Zealand vs South Africa
2011-03-24 - international - ODI - male - 433601 - India vs Australia
2011-03-23 - international - ODI - male - 433600 - Pakistan vs West Indies
2011-03-20 - international - ODI - male - 433598 - Kenya vs Zimbabwe
2011-03-20 - international - ODI - male - 433599 - India vs West Indies
2011-03-19 - international - ODI - male - 433596 - Australia vs Pakistan
2011-03-19 - international - ODI - male - 433597 - Bangladesh vs South Africa
2011-03-18 - international - ODI - male - 433594 - New Zealand vs Sri Lanka
2011-03-18 - international - ODI - male - 433595 - Ireland vs Netherlands
2011-03-17 - international - ODI - male - 433593 - England vs West Indies
2011-03-16 - international - ODI - male - 433592 - Australia vs Canada
2011-03-15 - international - ODI - male - 433591 - Ireland vs South Africa
2011-03-14 - international - ODI - male - 433589 - Pakistan vs Zimbabwe
2011-03-14 - international - ODI - male - 433590 - Bangladesh vs Netherlands
2011-03-13 - international - ODI - male - 433587 - Canada vs New Zealand
2011-03-13 - international - ODI - male - 433588 - Australia vs Kenya
2011-03-12 - international - ODI - male - 433586 - India vs South Africa
2011-03-11 - international - ODI - male - 433584 - Ireland vs West Indies
2011-03-11 - international - ODI - male - 433585 - Bangladesh vs England
2011-03-10 - international - ODI - male - 433583 - Sri Lanka vs Zimbabwe
2011-03-09 - international - ODI - male - 433582 - India vs Netherlands
2011-03-08 - international - ODI - male - 433581 - New Zealand vs Pakistan
2011-03-07 - international - ODI - male - 433580 - Canada vs Kenya
2011-03-06 - international - ODI - male - 433578 - India vs Ireland
2011-03-06 - international - ODI - male - 433579 - England vs South Africa
2011-03-05 - international - ODI - male - 433577 - Sri Lanka vs Australia
2011-03-04 - international - ODI - male - 433575 - New Zealand vs Zimbabwe
2011-03-04 - international - ODI - male - 433576 - Bangladesh vs West Indies
2011-03-03 - international - ODI - male - 433573 - Netherlands vs South Africa
2011-03-03 - international - ODI - male - 433574 - Canada vs Pakistan
2011-03-02 - international - ODI - male - 433572 - England vs Ireland
2011-03-01 - international - ODI - male - 433571 - Sri Lanka vs Kenya
2011-02-28 - international - ODI - male - 433569 - Netherlands vs West Indies
2011-02-28 - international - ODI - male - 433570 - Canada vs Zimbabwe
2011-02-27 - international - ODI - male - 433568 - India vs England
2011-02-26 - international - ODI - male - 433567 - Sri Lanka vs Pakistan
2011-02-25 - international - ODI - male - 433565 - Australia vs New Zealand
2011-02-25 - international - ODI - male - 433566 - Bangladesh vs Ireland
2011-02-24 - international - ODI - male - 433564 - South Africa vs West Indies
2011-02-23 - international - ODI - male - 433563 - Kenya vs Pakistan
2011-02-22 - international - ODI - male - 433562 - England vs Netherlands
2011-02-21 - international - ODI - male - 433561 - Australia vs Zimbabwe
2011-02-20 - international - ODI - male - 433559 - Kenya vs New Zealand
2011-02-20 - international - ODI - male - 433560 - Sri Lanka vs Canada
2011-02-19 - international - ODI - male - 433558 - Bangladesh vs India
2007-04-28 - international - ODI - male - 247507 - Australia vs Sri Lanka
2007-04-25 - international - ODI - male - 247506 - Australia vs South Africa
2007-04-24 - international - ODI - male - 247505 - New Zealand vs Sri Lanka
2007-04-21 - international - ODI - male - 247504 - West Indies vs England
2007-04-20 - international - ODI - male - 247503 - Australia vs New Zealand
2007-04-19 - international - ODI - male - 247502 - West Indies vs Bangladesh
2007-04-18 - international - ODI - male - 247501 - Ireland vs Sri Lanka
2007-04-17 - international - ODI - male - 247500 - England vs South Africa
2007-04-16 - international - ODI - male - 247499 - Australia vs Sri Lanka
2007-04-15 - international - ODI - male - 247498 - Bangladesh vs Ireland
2007-04-14 - international - ODI - male - 247497 - New Zealand vs South Africa
2007-04-13 - international - ODI - male - 247496 - Australia vs Ireland
2007-04-12 - international - ODI - male - 247495 - New Zealand vs Sri Lanka
2007-04-11 - international - ODI - male - 247494 - Bangladesh vs England
2007-04-10 - international - ODI - male - 247493 - West Indies vs South Africa
2007-04-09 - international - ODI - male - 247492 - Ireland vs New Zealand
2007-04-08 - international - ODI - male - 247491 - Australia vs England
2007-04-07 - international - ODI - male - 247490 - Bangladesh vs South Africa
2007-04-04 - international - ODI - male - 247489 - England vs Sri Lanka
2007-04-03 - international - ODI - male - 247488 - Ireland vs South Africa
2007-04-02 - international - ODI - male - 247487 - Bangladesh vs New Zealand
2007-04-01 - international - ODI - male - 247486 - West Indies vs Sri Lanka
2007-03-31 - international - ODI - male - 247485 - Australia vs Bangladesh
2007-03-30 - international - ODI - male - 247484 - England vs Ireland
2007-03-29 - international - ODI - male - 247483 - West Indies vs New Zealand
2007-03-28 - international - ODI - male - 247482 - South Africa vs Sri Lanka
2007-03-27 - international - ODI - male - 247481 - West Indies vs Australia
2007-03-25 - international - ODI - male - 247480 - Bangladesh vs Bermuda
2007-03-24 - international - ODI - male - 247478 - Australia vs South Africa
2007-03-24 - international - ODI - male - 247479 - England vs Kenya
2007-03-23 - international - ODI - male - 247476 - India vs Sri Lanka
2007-03-23 - international - ODI - male - 247477 - West Indies vs Ireland
2007-03-22 - international - ODI - male - 247474 - Netherlands vs Scotland
2007-03-22 - international - ODI - male - 247475 - Canada vs New Zealand
2007-03-21 - international - ODI - male - 247472 - Bangladesh vs Sri Lanka
2007-03-21 - international - ODI - male - 247473 - Pakistan vs Zimbabwe
2007-03-20 - international - ODI - male - 247470 - Scotland vs South Africa
2007-03-20 - international - ODI - male - 247471 - Kenya vs New Zealand
2007-03-19 - international - ODI - male - 247468 - Bermuda vs India
2007-03-19 - international - ODI - male - 247469 - West Indies vs Zimbabwe
2007-03-18 - international - ODI - male - 247466 - Australia vs Netherlands
2007-03-18 - international - ODI - male - 247467 - Canada vs England
2007-03-17 - international - ODI - male - 247464 - Bangladesh vs India
2007-03-17 - international - ODI - male - 247465 - Ireland vs Pakistan
2007-03-16 - international - ODI - male - 247462 - Netherlands vs South Africa
2007-03-16 - international - ODI - male - 247463 - England vs New Zealand
2007-03-15 - international - ODI - male - 247460 - Bermuda vs Sri Lanka
2007-03-15 - international - ODI - male - 247461 - Ireland vs Zimbabwe
2007-03-14 - international - ODI - male - 247458 - Australia vs Scotland
2007-03-13 - international - ODI - male - 247457 - West Indies vs Pakistan
2003-03-23 - international - ODI - male - 65286 - Australia vs India
2003-03-20 - international - ODI - male - 65285 - India vs Kenya
2003-03-18 - international - ODI - male - 65284 - Australia vs Sri Lanka
2003-03-15 - international - ODI - male - 65282 - Sri Lanka vs Zimbabwe
2003-03-15 - international - ODI - male - 65283 - Kenya vs Australia
2003-03-14 - international - ODI - male - 65281 - New Zealand vs India
2003-03-12 - international - ODI - male - 65280 - Zimbabwe vs Kenya
2003-03-11 - international - ODI - male - 65279 - Australia vs New Zealand
2003-03-10 - international - ODI - male - 65278 - India vs Sri Lanka
2003-03-08 - international - ODI - male - 65277 - Zimbabwe vs New Zealand
2003-03-07 - international - ODI - male - 65275 - Australia vs Sri Lanka
2003-03-07 - international - ODI - male - 65276 - Kenya vs India
2003-03-04 - international - ODI - male - 65273 - Pakistan vs Zimbabwe
2003-03-03 - international - ODI - male - 65270 - Canada vs New Zealand
2003-03-03 - international - ODI - male - 65271 - Netherlands vs Namibia
2003-03-03 - international - ODI - male - 65272 - Sri Lanka vs South Africa
2003-03-02 - international - ODI - male - 65269 - England vs Australia
2003-03-01 - international - ODI - male - 65267 - Kenya vs Bangladesh
2003-03-01 - international - ODI - male - 65268 - Pakistan vs India
2003-02-28 - international - ODI - male - 65265 - Zimbabwe vs Netherlands
2003-02-28 - international - ODI - male - 65266 - Sri Lanka vs West Indies
2003-02-27 - international - ODI - male - 65263 - Australia vs Namibia
2003-02-27 - international - ODI - male - 65264 - South Africa vs Canada
2003-02-26 - international - ODI - male - 65261 - Bangladesh vs New Zealand
2003-02-26 - international - ODI - male - 65262 - India vs England
2003-02-25 - international - ODI - male - 65260 - Pakistan vs Netherlands
2003-02-24 - international - ODI - male - 65258 - Kenya vs Sri Lanka
2003-02-24 - international - ODI - male - 65259 - Zimbabwe vs Australia
2003-02-23 - international - ODI - male - 65256 - Canada vs West Indies
2003-02-23 - international - ODI - male - 65257 - India vs Namibia
2003-02-22 - international - ODI - male - 65254 - Bangladesh vs South Africa
2003-02-22 - international - ODI - male - 65255 - England vs Pakistan
2003-02-19 - international - ODI - male - 65250 - India vs Zimbabwe
2003-02-19 - international - ODI - male - 65251 - Canada vs Sri Lanka
2003-02-19 - international - ODI - male - 65252 - England vs Namibia
2003-02-18 - international - ODI - male - 65249 - West Indies vs Bangladesh
2003-02-16 - international - ODI - male - 65246 - Netherlands vs England
2003-02-16 - international - ODI - male - 65247 - Pakistan vs Namibia
2003-02-16 - international - ODI - male - 65248 - South Africa vs New Zealand
2003-02-15 - international - ODI - male - 65244 - India vs Australia
2003-02-15 - international - ODI - male - 65245 - Canada vs Kenya
2003-02-13 - international - ODI - male - 65242 - New Zealand vs West Indies
2003-02-12 - international - ODI - male - 65240 - Kenya vs South Africa
2003-02-12 - international - ODI - male - 65241 - India vs Netherlands
2003-02-11 - international - ODI - male - 65238 - Australia vs Pakistan
2003-02-11 - international - ODI - male - 65239 - Canada vs Bangladesh
2003-02-10 - international - ODI - male - 65236 - Zimbabwe vs Namibia
2003-02-10 - international - ODI - male - 65237 - Sri Lanka vs New Zealand
2003-02-09 - international - ODI - male - 65235 - West Indies vs South Africa
